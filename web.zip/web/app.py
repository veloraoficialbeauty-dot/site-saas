from flask import Flask, render_template, request, redirect, url_for, session, flash
import sqlite3
import os
import sys
import shutil
import subprocess
import signal
import re
import psutil

# Adiciona o diretório pai ao sys.path para importar database
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

app = Flask(__name__)
app.secret_key = "master_secret_key_store_cc"

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DB_PATH = os.path.join(BASE_DIR, "main.db")
INSTANCES_DIR = os.path.join(BASE_DIR, "instances")

if not os.path.exists(INSTANCES_DIR):
    os.makedirs(INSTANCES_DIR)

def get_db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

def is_process_running(pid):
    """Verifica se um processo com o PID fornecido está ativo."""
    if not pid: return False
    try:
        process = psutil.Process(pid)
        return process.is_running() and process.status() != psutil.STATUS_ZOMBIE
    except (psutil.NoSuchProcess, psutil.AccessDenied, psutil.ZombieProcess):
        return False

import time

# Flags para o Windows rodar de forma independente
DETACHED_PROCESS = 0x00000008
CREATE_NEW_PROCESS_GROUP = 0x00000200

def start_bot_process(directory, bot_id, name):
    """Lógica unificada para iniciar o processo de um bot."""
    log_path = os.path.join(directory, "startup_error.log")
    try:
        # Tenta abrir o arquivo para escrita (truncando o conteúdo anterior)
        # Se falhar por estar em uso, tentamos um nome alternativo ou ignoramos a deleção
        try:
            err_file = open(log_path, "w", encoding="utf-8")
        except PermissionError:
            # Se o arquivo principal estiver travado, usa um temporário para não crashar o site
            log_path = os.path.join(directory, f"startup_error_{int(time.time())}.log")
            err_file = open(log_path, "w", encoding="utf-8")

        process = subprocess.Popen(
            [sys.executable, "bot.py"],
            cwd=directory,
            stdout=subprocess.DEVNULL,
            stderr=err_file, # Captura erros de inicialização
            creationflags=DETACHED_PROCESS | CREATE_NEW_PROCESS_GROUP if os.name == 'nt' else 0,
            close_fds=True 
        )
        
        # Fecha o handle no processo pai (o Popen manterá o handle aberto no processo filho)
        err_file.close()
        
        # Aguarda 3 segundos para ver se o bot não crashou logo de cara
        time.sleep(3)
        if not is_process_running(process.pid):
            error_msg = "Desconhecido (verifique os arquivos de log na pasta do bot)"
            if os.path.exists(log_path):
                try:
                    with open(log_path, "r", encoding="utf-8", errors="ignore") as f:
                        error_msg = f.read().strip() or "Erro silencioso no bot.py"
                except: pass
            print(f"❌ Bot '{name}' crashou imediatamente: {error_msg}")
            return False, error_msg

        db = get_db()
        db.execute("UPDATE managed_bots SET status = 'running', pid = ? WHERE id = ?", (process.pid, bot_id))
        db.commit()
        print(f"✅ Bot '{name}' iniciado com sucesso (PID: {process.pid})")
        return True, process.pid
    except Exception as e:
        print(f"❌ Falha ao iniciar bot '{name}': {e}")
        return False, str(e)

def sync_bots_status():
    """Sincroniza o status do banco de dados com a realidade dos processos."""
    db = get_db()
    bots = db.execute("SELECT id, name, pid, status, directory FROM managed_bots").fetchall()
    for bot in bots:
        actually_running = is_process_running(bot['pid'])
        if actually_running and bot['status'] != 'running':
            db.execute("UPDATE managed_bots SET status = 'running' WHERE id = ?", (bot['id'],))
        elif not actually_running and bot['status'] == 'running':
            db.execute("UPDATE managed_bots SET status = 'stopped', pid = NULL WHERE id = ?", (bot['id'],))
    db.commit()

def restart_active_bots():
    """Inicia todos os bots que deveriam estar rodando (status='running')."""
    print("🚀 Verificando bots ativos para inicialização...")
    db = get_db()
    active_bots = db.execute("SELECT id, name, directory, pid FROM managed_bots WHERE status = 'running'").fetchall()
    for bot in active_bots:
        if not is_process_running(bot['pid']):
            print(f"🔄 Reiniciando bot '{bot['name']}'...")
            start_bot_process(bot['directory'], bot['id'], bot['name'])
        else:
            print(f"🟢 Bot '{bot['name']}' já está rodando (PID: {bot['pid']})")

def format_expiration_date(date_str):
    """Garante que a data de expiração tenha data e hora."""
    if not date_str or date_str.lower() == "nunca":
        return "nunca"
    
    date_str = date_str.strip()
    # Se a data tiver apenas YYYY-MM-DD (comprimento 10)
    if len(date_str) == 10 and re.match(r"^\d{4}-\d{2}-\d{2}$", date_str):
        return f"{date_str} 23:59:59"
    
    return date_str

@app.route("/")
def index():
    if "logged_in" in session:
        return redirect(url_for("dashboard"))
    return render_template("login.html")

@app.route("/login", methods=["POST"])
def login():
    username = request.form.get("username")
    password = request.form.get("password")
    
    db = get_db()
    try:
        res = db.execute("SELECT web_user, web_pass FROM bot_license LIMIT 1").fetchone()
    except sqlite3.OperationalError:
        res = None
    
    db_user = res["web_user"] if res else "admin"
    db_pass = res["web_pass"] if res else "admin123"
    
    if username == db_user and password == db_pass:
        session["logged_in"] = True
        return redirect(url_for("dashboard"))
    
    flash("Usuário ou senha inválidos.", "danger")
    return redirect(url_for("index"))

@app.route("/logout")
def logout():
    session.pop("logged_in", None)
    return redirect(url_for("index"))

@app.route("/dashboard")
def dashboard():
    if "logged_in" not in session:
        return redirect(url_for("index"))
    
    sync_bots_status() # Garante que o status no site é real
    db = get_db()
    license_info = db.execute("SELECT * FROM bot_license LIMIT 1").fetchone()
    
    if not license_info:
        db.execute("INSERT INTO bot_license (expires_at) VALUES ('nunca')")
        db.commit()
        license_info = db.execute("SELECT * FROM bot_license LIMIT 1").fetchone()
    
    managed_bots = db.execute("SELECT * FROM managed_bots ORDER BY id DESC").fetchall()
    
    total_users = db.execute("SELECT COUNT(*) FROM users").fetchone()[0]
    total_sales = db.execute("SELECT COUNT(*) FROM sold_balance WHERE type='cards'").fetchone()[0]
    total_revenue = db.execute("SELECT SUM(value) FROM sold_balance WHERE type='auto'").fetchone()[0] or 0
    
    # Monitoramento de recursos
    try:
        cpu_usage = psutil.cpu_percent(interval=None)
        ram = psutil.virtual_memory()
        ram_usage = ram.percent
        # Total de processos Python rodando
        python_procs = len([p for p in psutil.process_iter(['name']) if 'python' in p.info['name'].lower()])
    except:
        cpu_usage = 0
        ram_usage = 0
        python_procs = 0

    bots_with_stats = []
    for bot in managed_bots:
        bot_dict = dict(bot)
        if bot['directory']:
            bot_db = os.path.join(bot['directory'], "main.db")
            if os.path.exists(bot_db):
                try:
                    conn = sqlite3.connect(bot_db)
                    c = conn.cursor()
                    bot_dict['users_count'] = c.execute("SELECT COUNT(*) FROM users").fetchone()[0]
                    bot_dict['sales_count'] = c.execute("SELECT COUNT(*) FROM sold_balance WHERE type='cards'").fetchone()[0]
                    conn.close()
                except:
                    bot_dict['users_count'] = 0
                    bot_dict['sales_count'] = 0
            else:
                bot_dict['users_count'] = 0
                bot_dict['sales_count'] = 0
        bots_with_stats.append(bot_dict)

    return render_template("dashboard.html", 
                           license=license_info, 
                           managed_bots=bots_with_stats,
                           total_users=total_users, 
                           total_sales=total_sales, 
                           total_revenue=total_revenue,
                           cpu_usage=cpu_usage,
                           ram_usage=ram_usage,
                           python_procs=python_procs)

@app.route("/bot/details/<int:bot_id>")
def bot_details(bot_id):
    if "logged_in" not in session: return redirect(url_for("index"))
    
    db = get_db()
    bot = db.execute("SELECT * FROM managed_bots WHERE id = ?", (bot_id,)).fetchone()
    if not bot:
        flash("Bot não encontrado.", "danger")
        return redirect(url_for("dashboard"))
    
    bot_stats = {}
    bot_config = {}
    if bot['directory']:
        bot_db = os.path.join(bot['directory'], "main.db")
        if os.path.exists(bot_db):
            try:
                conn = sqlite3.connect(bot_db)
                conn.row_factory = sqlite3.Row
                c = conn.cursor()
                bot_stats['users'] = c.execute("SELECT COUNT(*) FROM users").fetchone()[0]
                bot_stats['sales'] = c.execute("SELECT COUNT(*) FROM sold_balance WHERE type='cards'").fetchone()[0]
                bot_stats['revenue'] = c.execute("SELECT SUM(value) FROM sold_balance WHERE type='auto'").fetchone()[0] or 0
                bot_config = c.execute("SELECT * FROM bot_config LIMIT 1").fetchone()
                conn.close()
            except: pass
            
    bot_logs = []
    if bot['directory']:
        log_path = os.path.join(bot['directory'], "debug.log")
        if os.path.exists(log_path):
            try:
                with open(log_path, "r", encoding="utf-8", errors="ignore") as f:
                    bot_logs = [line.strip() for line in f.readlines()[-50:]]
            except: pass
            
    return render_template("bot_details.html", bot=bot, stats=bot_stats, config=bot_config, logs=bot_logs)

@app.route("/bot/update_config/<int:bot_id>", methods=["POST"])
def update_bot_config(bot_id):
    if "logged_in" not in session: return redirect(url_for("index"))
    
    db = get_db()
    bot = db.execute("SELECT directory FROM managed_bots WHERE id = ?", (bot_id,)).fetchone()
    if not bot or not bot['directory']:
        return redirect(url_for("dashboard"))

    bot_db = os.path.join(bot['directory'], "main.db")
    if os.path.exists(bot_db):
        try:
            conn = sqlite3.connect(bot_db)
            c = conn.cursor()
            store_name = request.form.get("store_name")
            support = request.form.get("support_user")
            c.execute("UPDATE bot_config SET store_name = ?, support_user = ?", (store_name, support))
            conn.commit()
            conn.close()
            flash("Configuração da instância atualizada!", "success")
        except Exception as e:
            flash(f"Erro ao atualizar: {e}", "danger")
            
    return redirect(url_for("bot_details", bot_id=bot_id))

@app.route("/bot/create", methods=["POST"])
def create_bot():
    if "logged_in" not in session: return redirect(url_for("index"))
    
    name = request.form.get("name")
    token = request.form.get("token")
    owner_id = request.form.get("owner_id")
    expires_at = format_expiration_date(request.form.get("expires_at"))
    
    if not name or not token:
        flash("Nome e Token são obrigatórios.", "warning")
        return redirect(url_for("dashboard"))
        
    safe_name = "".join([c for c in name if c.isalnum() or c in (' ', '-', '_')]).strip().replace(' ', '_').lower()
    bot_dir = os.path.join(INSTANCES_DIR, safe_name)
    
    if os.path.exists(bot_dir):
        flash(f"Já existe uma loja com o nome '{name}' (ou similar).", "danger")
        return redirect(url_for("dashboard"))

    try:
        os.makedirs(bot_dir)
        ignore_list = shutil.ignore_patterns('main.db*', '*.session*', '__pycache__', 'instances', 'web', 'debug.log', '.git', '.trae')
        for item in os.listdir(BASE_DIR):
            s = os.path.join(BASE_DIR, item)
            d = os.path.join(bot_dir, item)
            if os.path.isdir(s):
                if item not in ['instances', 'web', '__pycache__', '.git', '.trae']:
                    shutil.copytree(s, d, ignore=ignore_list)
            else:
                if not any(item.startswith(p) for p in ['main.db', 'bot_session', 'debug.log']):
                    shutil.copy2(s, d)

        config_path = os.path.join(bot_dir, "config.py")
        if os.path.exists(config_path):
            with open(config_path, "r", encoding="utf-8") as f:
                content = f.read()
            content = re.sub(r'BOT_TOKEN\s*=\s*".*?"', f'BOT_TOKEN = "{token}"', content)
            if owner_id:
                content = re.sub(r'ADMINS\s*=\s*\[.*?\]', f'ADMINS = [{owner_id}]', content)
                content = re.sub(r'SUDOERS\s*=\s*\[.*?\]', f'SUDOERS = [{owner_id}]', content)
            with open(config_path, "w", encoding="utf-8") as f:
                f.write(content)

        # 4. Salva no banco Master
        db = get_db()
        cur_res = db.execute("INSERT INTO managed_bots (name, token, owner_id, expires_at, directory, status) VALUES (?, ?, ?, ?, ?, ?)", (name, token, owner_id, expires_at, bot_dir, 'running'))
        bot_id = cur_res.lastrowid
        db.commit()

        # 4.1 Inicializa a bot_license na nova instância para não vir None
        bot_db_path = os.path.join(bot_dir, "main.db")
        # O bot ainda não criou o banco, mas podemos criar a estrutura mínima ou esperar ele ligar.
        # Melhor deixar o bot ligar e o Painel Web tratar o None.
        
        success, pid = start_bot_process(bot_dir, bot_id, name)
        if success:
            flash(f"Loja '{name}' provisionada e INICIADA automaticamente!", "success")
        else:
            flash(f"Loja '{name}' provisionada, mas falhou ao iniciar. Tente manualmente.", "warning")
            
    except Exception as e:
        flash(f"Erro ao criar bot: {e}", "danger")
        if os.path.exists(bot_dir): shutil.rmtree(bot_dir)
        
    return redirect(url_for("dashboard"))

@app.route("/bot/update/<int:bot_id>", methods=["POST"])
def update_managed_bot(bot_id):
    if "logged_in" not in session: return redirect(url_for("index"))
    
    name = request.form.get("name")
    token = request.form.get("token")
    owner_id = request.form.get("owner_id")
    expires_at = format_expiration_date(request.form.get("expires_at"))
    status = request.form.get("status")
    
    db = get_db()
    db.execute("""
        UPDATE managed_bots 
        SET name = ?, token = ?, owner_id = ?, expires_at = ?, status = ?
        WHERE id = ?
    """, (name, token, owner_id, expires_at, status, bot_id))
    db.commit()
    
    flash(f"Configurações do bot '{name}' atualizadas.", "success")
    return redirect(url_for("dashboard"))

@app.route("/bot/start/<int:bot_id>")
def start_bot(bot_id):
    if "logged_in" not in session: return redirect(url_for("index"))
    db = get_db()
    bot = db.execute("SELECT * FROM managed_bots WHERE id = ?", (bot_id,)).fetchone()
    if not bot or not bot['directory']: return redirect(url_for("dashboard"))
    
    # Sincroniza status antes de tentar iniciar
    if is_process_running(bot['pid']):
        db.execute("UPDATE managed_bots SET status = 'running' WHERE id = ?", (bot_id,))
        db.commit()
        flash(f"O bot '{bot['name']}' já está rodando.", "info")
        return redirect(url_for("dashboard"))

    success, result = start_bot_process(bot['directory'], bot_id, bot['name'])
    if success:
        flash(f"Bot '{bot['name']}' iniciado!", "success")
    else:
        flash(f"Erro ao iniciar o bot: {result}", "danger")
    return redirect(url_for("dashboard"))

@app.route("/bot/stop/<int:bot_id>")
def stop_bot(bot_id):
    if "logged_in" not in session: return redirect(url_for("index"))
    db = get_db()
    bot = db.execute("SELECT * FROM managed_bots WHERE id = ?", (bot_id,)).fetchone()
    if not bot or bot['status'] == 'stopped': return redirect(url_for("dashboard"))
    try:
        if bot['pid']:
            if os.name == 'nt': subprocess.run(['taskkill', '/F', '/T', '/PID', str(bot['pid'])])
            else: os.kill(bot['pid'], signal.SIGTERM)
        db.execute("UPDATE managed_bots SET status = 'stopped', pid = NULL WHERE id = ?", (bot_id,))
        db.commit()
        flash(f"Bot '{bot['name']}' parado.", "info")
    except:
        db.execute("UPDATE managed_bots SET status = 'stopped', pid = NULL WHERE id = ?", (bot_id,))
        db.commit()
    return redirect(url_for("dashboard"))

@app.route("/bot/delete/<int:bot_id>")
def delete_bot(bot_id):
    if "logged_in" not in session: return redirect(url_for("index"))
    db = get_db()
    bot = db.execute("SELECT * FROM managed_bots WHERE id = ?", (bot_id,)).fetchone()
    if bot:
        if bot['status'] == 'running':
            try:
                if os.name == 'nt': subprocess.run(['taskkill', '/F', '/T', '/PID', str(bot['pid'])])
                else: os.kill(bot['pid'], signal.SIGTERM)
            except: pass
        if bot['directory'] and os.path.exists(bot['directory']):
            try: shutil.rmtree(bot['directory'])
            except: pass
        db.execute("DELETE FROM managed_bots WHERE id = ?", (bot_id,))
        db.commit()
        flash("Bot removido com sucesso.", "info")
    return redirect(url_for("dashboard"))

@app.route("/bot/sync/<int:bot_id>")
def sync_bot_code(bot_id):
    if "logged_in" not in session: return redirect(url_for("index"))
    
    db = get_db()
    bot = db.execute("SELECT * FROM managed_bots WHERE id = ?", (bot_id,)).fetchone()
    if not bot or not bot['directory']:
        flash("Bot não encontrado.", "danger")
        return redirect(url_for("dashboard"))

    try:
        # 1. Tenta parar o bot se estiver rodando
        if is_process_running(bot['pid']):
            try:
                if os.name == 'nt': subprocess.run(['taskkill', '/F', '/T', '/PID', str(bot['pid'])], capture_output=True)
                else: os.kill(bot['pid'], signal.SIGTERM)
                time.sleep(3) # Aumentado para 3s para garantir liberação no Windows
            except: pass

        # 2. Função auxiliar para cópia robusta (evita rmtree na raiz do bot)
        def robust_copy(src, dst):
            if not os.path.exists(dst):
                os.makedirs(dst)
            for item in os.listdir(src):
                s = os.path.join(src, item)
                d = os.path.join(dst, item)
                
                # Pula arquivos protegidos e pastas do sistema master
                if any(p in item for p in ['main.db', 'bot_session', 'debug.log', 'startup_error', 'instances', 'web', '__pycache__', '.git', '.trae']):
                    continue
                    
                try:
                    if os.path.isdir(s):
                        robust_copy(s, d)
                    else:
                        shutil.copy2(s, d)
                except PermissionError:
                    print(f"⚠️ Ignorado por estar em uso: {item}")
                    continue
                except Exception as e:
                    print(f"⚠️ Erro ao copiar {item}: {e}")

        # Executa a cópia
        robust_copy(BASE_DIR, bot['directory'])

        # 3. Re-aplica as configurações específicas
        config_path = os.path.join(bot['directory'], "config.py")
        if os.path.exists(config_path):
            with open(config_path, "r", encoding="utf-8") as f:
                content = f.read()
            content = re.sub(r'BOT_TOKEN\s*=\s*".*?"', f'BOT_TOKEN = "{bot["token"]}"', content)
            if bot['owner_id']:
                content = re.sub(r'ADMINS\s*=\s*\[.*?\]', f'ADMINS = [{bot["owner_id"]}]', content)
                content = re.sub(r'SUDOERS\s*=\s*\[.*?\]', f'SUDOERS = [{bot["owner_id"]}]', content)
            with open(config_path, "w", encoding="utf-8") as f:
                f.write(content)

        # 4. Inicia o bot novamente
        success, result = start_bot_process(bot['directory'], bot_id, bot['name'])
        
        if success:
            flash(f"Código do bot '{bot['name']}' sincronizado e bot REINICIADO!", "success")
        else:
            flash(f"Código sincronizado, mas houve um erro ao iniciar: {result}", "warning")

    except Exception as e:
        flash(f"Erro crítico na sincronização: {e}", "danger")
        
    return redirect(url_for("bot_details", bot_id=bot_id))

@app.route("/update_license", methods=["POST"])
def update_license():
    if "logged_in" not in session: return redirect(url_for("index"))
    db = get_db()
    db.execute("UPDATE bot_license SET pix_api_key = ?, daily_price = ?, weekly_price = ?, monthly_price = ?, expires_at = ?", (request.form.get("pix_api_key"), request.form.get("daily_price"), request.form.get("weekly_price"), request.form.get("monthly_price"), format_expiration_date(request.form.get("expires_at"))))
    db.commit()
    flash("Configurações atualizadas!", "success")
    return redirect(url_for("dashboard"))

@app.route("/update_auth", methods=["POST"])
def update_auth():
    if "logged_in" not in session: return redirect(url_for("index"))
    db = get_db()
    db.execute("UPDATE bot_license SET web_user = ?, web_pass = ?", (request.form.get("web_user"), request.form.get("web_pass")))
    db.commit()
    flash("Acesso atualizado!", "success")
    return redirect(url_for("dashboard"))

if __name__ == "__main__":
    restart_active_bots() # Reinicia os bots ativos ao ligar o site
    # Desativa o reloader para evitar quedas durante a sincronização
    app.run(host="0.0.0.0", port=5000, debug=True, use_reloader=False)
